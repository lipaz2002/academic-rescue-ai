const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getSources: () => ipcRenderer.invoke('get-sources'),
  checkMic: () => ipcRenderer.invoke('check-mic'),
  saveScreenshots: (shots) => ipcRenderer.invoke('save-screenshots', shots),
  openPath: (p) => ipcRenderer.invoke('open-path', p),
});
