const { app, BrowserWindow, ipcMain, desktopCapturer, systemPreferences, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 780,
    minWidth: 900,
    minHeight: 660,
    backgroundColor: '#020208',
    titleBarStyle: 'hiddenInset',
    trafficLightPosition: { x: 18, y: 18 },
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    title: 'AcademicRescue AI',
    show: false,
  });

  mainWindow.loadFile('index.html');
  mainWindow.once('ready-to-show', () => mainWindow.show());
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

ipcMain.handle('get-sources', async () => {
  const sources = await desktopCapturer.getSources({ types: ['window', 'screen'], fetchWindowIcons: true });
  return sources.map(s => ({ id: s.id, name: s.name, thumbnail: s.thumbnail.toDataURL() }));
});

ipcMain.handle('check-mic', async () => {
  if (process.platform === 'darwin') {
    const status = systemPreferences.getMediaAccessStatus('microphone');
    if (status !== 'granted') return await systemPreferences.askForMediaAccess('microphone');
    return true;
  }
  return true;
});

ipcMain.handle('save-screenshots', async (event, screenshots) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory'],
    message: 'בחר תיקייה לשמירת צילומי המסך'
  });
  if (result.canceled) return null;
  const dir = result.filePaths[0];
  screenshots.forEach((dataUrl, i) => {
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');
    fs.writeFileSync(path.join(dir, `screenshot_${String(i+1).padStart(2,'0')}.jpg`), base64, 'base64');
  });
  shell.openPath(dir);
  return dir;
});

ipcMain.handle('open-path', async (event, p) => {
  shell.openPath(p);
});
